<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kantin Dharma Wanita | <?php echo $__env->yieldContent('title'); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="<?php echo e(asset('assets/js/darkmode.js')); ?>"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">

</head>

<body class="bg-gray-50 dark:bg-gray-900 font-sans transition-colors duration-200">

    <div class="flex h-screen overflow-hidden">
        <?php if(!request()->is('login') && !request()->is('register')): ?>
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <div class="flex flex-col flex-1 overflow-hidden">
            <?php if(!request()->is('login') && !request()->is('register')): ?>
                <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <main class="flex-1 overflow-y-auto">
                <div class="px-4 py-6 sm:px-6 lg:px-8">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>

        </div>
    </div>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('custom_script'); ?>
    <script src="<?php echo e(asset('assets/js/sweetalert.js')); ?>"></script>
    <script src='<?php echo e(asset('assets/js/script.js')); ?>'></script>
</body>

</html>
<?php /**PATH E:\Applications\Laravel Project\dashboard-kasir\resources\views/layouts/main.blade.php ENDPATH**/ ?>